Machine Learning w/ Basketball Stats
Kaleb Hannan
11-25-2024
HW5
Classwork for COS 470 at the Univerisy of Maine Orono

# Discription:  
This program is a Machine Learning model that perdicts the number of wins that a Basketball team will get
based on there season statistics.

This Zip file includes the code for my ml model which is in the COS470HW5.py file
The script that I used to split the data into testing and tranning data called COS470HW5SplitData.py
And also 4 csv files 2 for each set of data.  The first one if for the data split my percent, This are in the
files called test_data_percent.csv and traning_data_percent.csv.  The data split by year is in the csv files
called test_data_year.csv and traning_data_year.csv.

The program as it is set up right now is using the est_data_percent.csv and traning_data_percent.csv files.  
This Files need do be in a folder called HW5 to work as the path were the file in my code is is 
HW5/traning_data_percent.csv and HW5/test_data_percent.csv.

What I tryed and my approch is in a PDF called COS 470 HW5 that will explain what I tried to do to accomplish the 
task for this HW assinment.

# Dependencies:
python 3
pytourch
pandas
sklearn
matplotlib

# How to Run the Program:
python3 COS470HW5.py